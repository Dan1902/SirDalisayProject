@extends('layouts.base')
@section('body')
    <style>
        * {
            margin-top: 10px;
        }

        .left-col {
            float: left;
            width: 25%;
        }

        .center-col {
            float: left;
            width: 50%;
        }

        .right-col {
            float: left;
            width: 25%;
        }
    </style>

    <div class="container">

        {{-- <button type="button" class="btn btn-info btn-lg" data-bs-toggle="modal" data-bs-target="#customerModal">New
            Customer
            <span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>

        <button type="button" class="btn btn-info btn-lg" id="customerbtn" style="float: right">Show
            Customers<span class="glyphicon glyphicon-plus" aria-hidden="true"></span></button>
        <div class="table-responsive"> --}}

        <table id="itable" class="table table-striped table-hover">
            <thead>
                <tr>
                    <th>Customer ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Phone</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="ibody">
            </tbody>
        </table>
    </div>
    </div>

    <div class="modal fade" id="customerModal" role="dialog" style="display:none">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Create New Customer</h4>

                    <div class="modal-body">
                        <form id="iform" action="#" method="#" enctype="multipart/form-data">
                            @csrf
                            <!-- {{-- <input type="hidden" name="itemimage" id="itemimage"> --}} -->
                            <div class="form-group">
                                <input type="hidden" class="form-control customer_id" id="customer_id" name="customer_id">
                            </div>
                            <div class="form-group">
                                <label for="fname" class="control-label">First Name</label>
                                <input type="text" class="form-control" id="fname" name="fname">
                            </div>
                            <div class="form-group">
                                <label for="lname" class="control-label">Last Name</label>
                                <input type="text" class="form-control" id="lname" name="lname">
                            </div>
                            <div class="form-group">
                                <label for="lname" class="control-label">Address</label>
                                <input type="text" class="form-control " id="address" name="address"></text>
                            </div>
                            <div class="form-group">
                                <label for="fname" class="control-label">Phone</label>
                                <input type="text" class="form-control " id="phone" name="phone">
                            </div>
                            <!-- <div class="form-group">
                                <label for="address" class="control-label">Customer Image</label>
                                <input type="file" class="form-control" id="imagePath" name="uploads">
                            </div>
                            {{-- <div class="mt-2" id="imagePath">

                            </div> --}} -->
                        </form>
                    </div>

                </div>

                <div class="modal-footer" id="btnss">
                    <button type="button" class="btn btn-default" data-bs-dismiss="modal">Close</button>
                    <button id="customerSubmit" type="submit" class="btn btn-primary">Save</button>
                    <button id="customerupdate" type="submit" class="btn btn-primary">Update</button>
                </div>

            </div>
        </div>
    </div>
@endsection
