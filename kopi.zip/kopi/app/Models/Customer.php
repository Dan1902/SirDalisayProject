<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    public $primaryKey = 'customer_id';
    protected $guarded = ['customer_id'];
    protected $fillable = [
        'fname', 'lname', 'address',
        'phone',
    ];
}
